module.exports = (req, res) => {
  res.json({
    message: "Hello Open Runtimes 👋",
  });
};
